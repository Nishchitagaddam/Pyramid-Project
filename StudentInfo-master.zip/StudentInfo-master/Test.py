def multiply(a, b):
	return a * b;

def test_numbers_3_4():
    assert multiply(4, 5) == 20
    assert multiply(4, 7) == 28
